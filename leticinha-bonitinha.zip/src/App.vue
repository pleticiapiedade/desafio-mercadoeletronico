<template>
  <div id="nav">
    <router-link to="/">Home</router-link> |
  </div>
  <router-view />
</template>

<script>
import "./assets/style.scss"

export default {
  setup() {
    
  },
}
</script>

<style lang="scss">
</style>
